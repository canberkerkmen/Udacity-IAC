Deploy Static Website on AWS

In this project, you will deploy a static website to AWS using S3 and IAM.

The files included are: 

index.html - The Index document for the website.
/img - The background image file for the website.
/vendor - Bootssrap CSS framework.
/css - CSS files for the website.


